package com.jacob.estore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
